# Changelog

All notable changes to this project will be documented in this file.

## [1.0.0] - 2025-01-18

### Added
- Initial release
- Blocks autofill on email, username, and password fields
- MutationObserver for dynamically loaded forms
- Support for Chrome, Brave, Edge, and Firefox
